// About.js

import React from 'react';

const About = () => {
  return (

    <>
      <div className='container'>
        <h1>M Jamshaid About us page</h1>
      </div>
    </>
  );
};

export default About;
