import React from 'react'
import Weather from './Weather'

const Home = () => {
  return (
    <div>
      <>
      <Weather/>


      {/* <h2>its h2</h2>
      <h3>its h2</h3>
      <h4>its h2</h4>
      <h5>its h2</h5>
      <h6>its h2</h6>
      <p>its ParaGraph</p> */}

      </>
    </div>
  )
}

export default Home
